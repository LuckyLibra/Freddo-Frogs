var express = require('express');
var router = express.Router();
var argon2 = require('argon2');
const {OAuth2Client} = require('google-auth-library');
const client = new OAuth2Client("454170287764-11qdcro9uap8mq4oq62071kvb67ob530.apps.googleusercontent.com");


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('login', { title: 'Evently - Sign In' });
});


/* Session Test */
router.get('/test', function(req, res, next) {
  if('user' in req.session){
    res.json(req.session.user);
  } else {
    res.send('This is a test');
  }
});


/**
 *  Corey Stuff
 *
 *  NOTE: This might need updating if anythings been added,
 *  I've also added some little things in here to work with sessions
 *  ( marked these as ( Reilly Added ) )
 *
 */

router.post('/signup', async function(req, res, next) {
  if ('username' in req.body && 'password' in req.body) { //ONLY IF USERNAME & PASSWORD IN REQUEST...
    req.pool.getConnection(async function(err, connection) { //Establish a Connection to the Database
      if(err) {               //====================
        res.sendStatus(500);  //===Error Handling===
        console.log(err);
        return;               //====================
      }
      var username = req.body.username;
      /*ARGON 2 PASSWORD HASHING*/
      try {
        var phash = await argon2.hash(req.body.password);
      } catch (err) {
        res.sendStatus(500);
        console.log(err);
        return;
      }

      // GET DETAILS c also connection query below has email and placeholder image
      //
      var email = req.body.email ;

      var query = "INSERT INTO User VALUES (UUID(), ?, ?, NULL);INSERT INTO User_Profile VALUES (UUID(), (SELECT user_ID FROM User WHERE username = ?), NULL, NULL, ?, ?);INSERT INTO User_Preferences (profile_ID) VALUES ((SELECT profile_ID FROM User_Profile WHERE user_ID = (SELECT user_ID FROM User WHERE username = ?)));INSERT INTO User_Role VALUES (2, (SELECT profile_ID FROM User_Profile WHERE user_ID = (SELECT user_ID FROM User WHERE username = ?)));INSERT INTO Google_Calendar VALUES (UUID(), (SELECT user_ID FROM User WHERE username = ?), NULL);";
      connection.query(query, [username,phash,username,email,'images/placeholder.png',username,username,username], function(err, rows, fields) {
        connection.release();
        if (err) {
          res.sendStatus(500);
          console.log(err);
          return;
        }

        // ADD SESSION USER ( Reilly Added )
        //
        req.session.user = username ;
        req.session.email = email ;

        res.sendStatus(200);
        res.redirect('login.html')
      });
    });
  }
});

//This function below creates a user in the database, when the user logs in with their google account, & is not already in the database.
//It will add them with their google id and their email from their google account.
function createaccountwithgoogle(req, res, id, usremail) { //takes in req, res, Google User ID and Google User's Email.
  req.pool.getConnection(async function(err, connection) { //Establish a Connection to the Database
    if(err) {               //====================
      res.sendStatus(500);  //===Error Handling===
      console.log(err);
      return;               //====================
    }
    var query = "INSERT INTO User VALUES (UUID(), NULL, NULL, ?);INSERT INTO User_Profile VALUES (UUID(), (SELECT user_ID FROM User WHERE google_ID = ?), NULL, NULL, ?, NULL);INSERT INTO User_Preferences (profile_ID) VALUES ((SELECT profile_ID FROM User_Profile WHERE user_ID = (SELECT user_ID FROM User WHERE google_ID = ?)));INSERT INTO User_Role VALUES (2, (SELECT profile_ID FROM User_Profile WHERE user_ID = (SELECT user_ID FROM User WHERE google_ID = ?)));INSERT INTO Google_Calendar VALUES (UUID(), (SELECT user_ID FROM User WHERE google_ID = ?), NULL);";
    connection.query(query, [id,id,usremail,id,id,id], function(err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(500);
        console.log(err);
        return;
      }
      res.sendStatus(200);
    });
  });
};


router.post('/login', async function(req, res, next) { //REGULAR LOGIN (from submit button on login.html)
    if ('username' in req.body && 'password' in req.body) { //ONLY IF USERNAME & PASSWORD IN REQUEST (request for normal, non-google login)
        req.pool.getConnection(function(err, connection) { //Establish a Connection to the Database
            if(err) {               //====================
              res.sendStatus(500);  //===Error Handling===
              return;               //====================
            }

            var username = req.body.username;
            var query = "SELECT password FROM User WHERE username = ?;"; // Query the database for user's Hashed+Salted password

            connection.query(query, [username], async function(err, rows, fields) {
              connection.release(); //Release the connection
              if(err) {              //====================
                res.sendStatus(500); //===Error Handling===
                return;              //====================
              }
              var pass = JSON.stringify(rows[0]); //{"password":"<password>"}
              var passwd = JSON.parse(pass);
              var phash = passwd.password;
              try {
                if (await argon2.verify(phash, req.body.password)) { //if the passwords match

                  // ADD SESSION - USER ( Reilly Added )
                  //
                  req.session.user = req.body.username ;

                  res.sendStatus(200);
                  res.redirect('Homepage.html')

                } else {//password didnt match
                  res.sendStatus(401);
                  return;
                }
              } catch (err) {
                //internal failure
                res.sendStatus(500);
                console.log(err);
                return;
              }
            });
        });
    }
    else if ('token' in req.body) { //TOKEN LOGIN (from Sign-in With Google)
        let subID = null;
        async function verify() {
            const ticket = await client.verifyIdToken({
                idToken: req.body.token,
                audience: "454170287764-11qdcro9uap8mq4oq62071kvb67ob530.apps.googleusercontent.com",  // Specify the CLIENT_ID of the app that accesses the backend
                // Or, if multiple clients access the backend:
                //[CLIENT_ID_1, CLIENT_ID_2, CLIENT_ID_3]
            });
            const payload = ticket.getPayload();
            const userid = payload['sub'];             //THE ID OF OUR USER!!! add to 'google-id'
            subID = payload['sub'];
            usremail = payload['email'];
            //const familyname = payload['family_name']; //User's Last Name
            //const givenname = payload['given_name'];   //User's First Name
        }
        verify().then(function(){ //If Successful
        req.pool.getConnection(function(err, connection) {
        if(err) {               //====================
            res.sendStatus(500);  //===Error Handling===
            console.log(err);     //====================
            return;
        }
        var query = "SELECT google_id FROM User WHERE google_id = ?;"; //SELECT first_name,last_name FROM User_Profile WHERE first_name = ? AND last_name = ?;
        connection.query(query, [subID], function(err, rows, fields) {
            connection.release(); //Release the connection
            if (err) {              //====================
            res.sendStatus(500);  //===Error Handling===
            console.log(err);     //====================
            return;
            }
            if (rows.length > 0){
                res.sendStatus(200);
            } else {//If user was not found in the database.
              console.log('User Did Not Exist. Adding To The Database...');
              createaccountwithgoogle(req, res, subID, usremail); //call this function, which sets up a new user
            }
                });
            });
        }).catch(function () { //If Error Occurs
            res.sendStatus(401);
        });
    }
});


/**
 *
 *  REILLY STUFF BELOW
 *  - Admin Routes
 *
 */

/**
 *  Get User Session Data
 */
 router.get('/get_session', function(req, res, next) {

  if('user' in req.session)
  {
    req.pool.getConnection(function(error,connection){
      if(error){
        console.log(error) ;
        res.sendStatus(500) ;
        return ;
      }

      let query = "SELECT User.user_ID, username, email, first_name, last_name, image_url , role_ID FROM User, User_Role, User_Profile WHERE User_Role.profile_ID = User_Profile.profile_ID AND User_Profile.user_ID = User.user_ID AND User.username = ? ;" ;
      connection.query(query, [ req.session.user ], function(error, rows, fields) {
        connection.release(); // release connection
        if (error) {
          console.log(error);
          res.sendStatus(500);
          return;
        }

        // Get session user ID
        //
        req.session.user_ID = rows[0].user_ID ;

        res.json(rows[0]) ;
      });

    });
  }

  else
  {
    console.log(error) ;
    res.sendStatus( 500 ) ;
    return ;
  }


});

/**
 * Returns list of users in database
 * For displaying to admins, in order for them to manage all users.
 */
router.get('/user_list', function(req, res, next) {

  req.pool.getConnection(function(error,connection){
    if(error){
      console.log(error);
      res.sendStatus(500);
      return;
    }

    let query = "SELECT username, role_name FROM User u INNER JOIN User_Profile up ON u.user_ID = up.user_ID INNER JOIN User_Role ur ON up.profile_ID = ur.profile_ID INNER JOIN Role r ON ur.role_ID = r.role_ID ORDER BY username ASC;" ;

    connection.query(query, function(error, rows, fields) {
      connection.release(); // release connection
      if (error) {
        console.log(error);
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});


/**
 * Used when admins change a users role.
 * updates user role as:
 * 1 = Admin
 * 2 = User
 *
 * NOTE: Should probably put password confirmation or sessions (to confirm is admin) in here for security.
 */
router.put('/update_role', function(req, res, next) {

  req.pool.getConnection(function(error,connection){
    if(error){
      console.log(error);
      res.sendStatus(500);
      return;
    }

    let query = "UPDATE User_Role SET User_Role.role_ID = ? WHERE User_Role.profile_ID = (SELECT profile_ID FROM User_Profile WHERE user_ID = (SELECT user_ID FROM User WHERE User.username = ?)) ;" ;
    connection.query(query, [ req.body.role_ID, req.body.username ], function(error, rows, fields) {

        connection.release(); // release connection
        if (error) {
          console.log(error);
          res.sendStatus(500);
          return;
        }

        res.send();
      });
    });
});


/**
 * Used by admins to create new users.
 * ( pretty much same as signup )
 * Except able to select a role for new user.
 *
 * NOTE: Should probably put password confirmation or sessions (to confirm is admin) in here for security.
 * Also emails need validation but I don't know how to implement this.
 */
router.post('/create_new_user', async function(req, res, next) {
  if ('username' in req.body && 'password' in req.body) { //ONLY IF USERNAME & PASSWORD IN REQUEST...
    req.pool.getConnection(async function(err, connection) { //Establish a Connection to the Database
      if(err) {               //====================
        res.sendStatus(500);  //===Error Handling===
        console.log(err);
        return;               //====================
      }
      var username = req.body.username;
      /*ARGON 2 PASSWORD HASHING*/
      try {
        var phash = await argon2.hash(req.body.password);
      } catch (err) {
        res.sendStatus(500);
        console.log(err);
        return;
      }
      var email = req.body.email ;
      var role = req.body.role ;

      var query = "INSERT INTO User VALUES (UUID(), ?, ?, NULL);INSERT INTO User_Profile VALUES (UUID(), (SELECT user_ID FROM User WHERE username = ?), NULL, NULL, ?, NULL);INSERT INTO User_Preferences (profile_ID) VALUES ((SELECT profile_ID FROM User_Profile WHERE user_ID = (SELECT user_ID FROM User WHERE username = ?)));INSERT INTO User_Role VALUES (?, (SELECT profile_ID FROM User_Profile WHERE user_ID = (SELECT user_ID FROM User WHERE username = ?)));INSERT INTO Google_Calendar VALUES (UUID(), (SELECT user_ID FROM User WHERE username = ?), NULL);";
      connection.query(query, [username,phash,username,email,username,role,username,username], function(err, rows, fields) {
        connection.release();
        if (err) {
          res.sendStatus(500);
          console.log(err);
          return;
        }

        res.sendStatus(200);
      });
    });
  }
});

/**
 * Delete User
 *
 * ( Note: check if admin first needs to be done. )
 */
router.delete('/delete_user', function(req, res, next) {

  req.pool.getConnection(function(error,connection){
    if(error){
      console.log(error);
      res.sendStatus(500);
      return;
    }

    let query = "DELETE FROM User WHERE username = ? ;" ;
    connection.query(query, [ req.body.username ], function(error, rows, fields) {

        connection.release(); // release connection
        if (error) {
          console.log(error);
          res.sendStatus(500);
          return;
        }

        res.send();
      });
    });
});

/**
 *
 *  REILLY STUFF BELOW
 *  - User Routes
 *
 */


/**
 * Change User Username
 *
 */
 router.put('/change_username', function(req, res, next) {

  req.pool.getConnection(function(error,connection){
    if(error){
      console.log(error);
      res.sendStatus(500);
      return;
    }

    console.log( req.body.username ) ;
    console.log( req.body.user_ID ) ;

    let query = "UPDATE User SET User.username = ? WHERE user_ID = ? ;" ;
    connection.query(query, [ req.body.username, req.body.user_ID ], function(error, rows, fields) {

        connection.release(); // release connection
        if (error) {
          console.log(error);
          res.sendStatus(500);
          return;
        }

        req.session.user = req.body.username ;

        res.send();
    });
  });
});

/**
 * Change User Image
 *
 */


/**
 * Change User Email
 *
 */
 router.put('/change_email', function(req, res, next) {

  req.pool.getConnection(function(error,connection){
    if(error){
      console.log(error);
      res.sendStatus(500);
      return;
    }

    console.log( req.body.email ) ;
    console.log( req.body.user_ID ) ;

    let query = "UPDATE User_Profile SET User_Profile.email = ? WHERE User_Profile.user_ID = ? ;" ;
    connection.query(query, [ req.body.email, req.body.user_ID ], function(error, rows, fields) {

        connection.release(); // release connection
        if (error) {
          console.log(error);
          res.sendStatus(500);
          return;
        }

        req.session.email = req.body.email ;

        res.send();
    });
  });
});


/**
 * Change User First Name
 *
 */
 router.put('/change_firstname', function(req, res, next) {

  req.pool.getConnection(function(error,connection){
    if(error){
      console.log(error);
      res.sendStatus(500);
      return;
    }

    console.log( req.body.email ) ;
    console.log( req.body.user_ID ) ;

    let query = "UPDATE User_Profile SET User_Profile.first_name = ? WHERE User_Profile.user_ID = ? ;" ;
    connection.query(query, [ req.body.first_name, req.body.user_ID ], function(error, rows, fields) {

        connection.release(); // release connection
        if (error) {
          console.log(error);
          res.sendStatus(500);
          return;
        }

        req.session.first_name = req.body.first_name ;

        res.send();
    });
  });
});


/**
 * Change User Last Name
 *
 */
 router.put('/change_lastname', function(req, res, next) {

  req.pool.getConnection(function(error,connection){
    if(error){
      console.log(error);
      res.sendStatus(500);
      return;
    }

    console.log( req.body.email ) ;
    console.log( req.body.user_ID ) ;

    let query = "UPDATE User_Profile SET User_Profile.last_name = ? WHERE User_Profile.user_ID = ? ;" ;
    connection.query(query, [ req.body.last_name, req.body.user_ID ], function(error, rows, fields) {

        connection.release(); // release connection
        if (error) {
          console.log(error);
          res.sendStatus(500);
          return;
        }

        req.session.last_name = req.body.last_name ;

        res.send();
    });
  });
});

var nodemailer = require('nodemailer');
const { response } = require('express');


// email send

router.post('/sendEmail', function(req, res, next) {

  //The output contains the message which will be sent to the the receiver
  //The body names are based on the assumed inputs (names from the evently.sql doc) on the add event form
  let output = `<p>Hello!</p><p>You have been invited to ${req.body.event_name} on ${req.body.date_time_ID} at ${req.body.location_ID} by ${req.body.event_author}</p> <p>We hope you have a lovely time,</p><p>Made with ❤ by Team Freddo Frogs © 2022 Evently</p>;`

  //This transporter has the access information for the account it will utilise (my gmail i made when i was 7 and couldn't spell narwhal and is now only home to spam mail)
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user:'narwhalehugger@gmail.com',
      pass:'Kafkaesque@1'
    }
  });

  receiver = req.body.email;
  const mailOptions = {
    from: 'narwhalehugger@gmail.com', // sender address
    to: receiver, // target
    subject: 'Evently Notification', // Subject line
    html: output
  };

    // send mail with defined transport object
    transporter.sendMail(mailOptions, function (err, info) {
      if(err)
        console.log(err)
      else
        console.log(info);
   });

});

const fs = require('fs');
const readline = require('readline');
const {google} = require('googleapis');

// If modifying these scopes, delete token.json.
const SCOPES = ['https://www.googleapis.com/auth/calendar.readonly'];
// The file token.json stores the user's access and refresh tokens, and is
// created automatically when the authorization flow completes for the first
// time.
const TOKEN_PATH = 'token.json';

// Load client secrets from a local file.
fs.readFile('credentials.json', (err, content) => {
  if (err) return console.log('Error loading client secret file:', err);
  // Authorize a client with credentials, then call the Google Calendar API.
  authorize(JSON.parse(content), listEvents);
});

/**
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 */
function authorize(credentials, callback) {
  const {client_secret, client_id, redirect_uris} = credentials.installed;
  const oAuth2Client = new google.auth.OAuth2(
      client_id, client_secret, redirect_uris[0]);

  // Check if we have previously stored a token.
  fs.readFile(TOKEN_PATH, (err, token) => {
    if (err) return getAccessToken(oAuth2Client, callback);
    oAuth2Client.setCredentials(JSON.parse(token));
    callback(oAuth2Client);
  });
}

/**
 * Get and store new token after prompting for user authorization, and then
 * execute the given callback with the authorized OAuth2 client.
 * @param {google.auth.OAuth2} oAuth2Client The OAuth2 client to get token for.
 * @param {getEventsCallback} callback The callback for the authorized client.
 */
function getAccessToken(oAuth2Client, callback) {
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
  });
  console.log('Authorize this app by visiting this url:', authUrl);
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  rl.question('Enter the code from that page here: ', (code) => {
    rl.close();
    oAuth2Client.getToken(code, (err, token) => {
      if (err) return console.error('Error retrieving access token', err);
      oAuth2Client.setCredentials(token);
      // Store the token to disk for later program executions
      fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
        if (err) return console.error(err);
        console.log('Token stored to', TOKEN_PATH);
      });
      callback(oAuth2Client);
    });
  });
}

/**
 * Lists the next 10 events on the user's primary calendar.
 * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
 */
function listEvents(auth) {
  const calendar = google.calendar({version: 'v3', auth});
  calendar.events.list({
    calendarId: 'primary',
    timeMin: (new Date()).toISOString(),
    maxResults: 10,
    singleEvents: true,
    orderBy: 'startTime',
  }, (err, res) => {
    if (err) return console.log('The API returned an error: ' + err);
    const events = res.data.items;
    if (events.length) {
      console.log('Upcoming 10 events:');
      events.map((event, i) => {
        const start = event.start.dateTime || event.start.date;
        console.log(`${start} - ${event.summary}`);
      });
    } else {
      console.log('No upcoming events found.');
    }
  });
}


module.exports = router;


