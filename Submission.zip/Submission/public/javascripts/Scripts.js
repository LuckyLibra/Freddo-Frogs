
// Google Sign-In Button function
function onSignIn(googleUser) {
    var id_token = googleUser.getAuthResponse().id_token;
    var profile = googleUser.getBasicProfile();
    console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
    console.log('Name: ' + profile.getName());
    console.log('Image URL: ' + profile.getImageUrl());
    console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.

    // AJAX Post Request to Our Server
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert('Login Successful!');

            // Reilly (Added - Redirect)
            //
            window.location.href = "/Homepage.html" ;

        } else if (this.readyState == 4 && this.status >= 400) {
            alert('Login Failed');
        }
    };
    xhttp.open("POST", "/login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({token: googleUser.getAuthResponse().id_token}));
}

/* Google's Sign Out Function, for signing users out of the web application */
function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
      console.log('User signed out.');
    });
}

// Log-In
function sendLogin() {
    var usr = document.getElementById("Uname").value; //Username
    var pwd = document.getElementById("Pname").value; //Password
    /*CHECKING FOR NON-NULL VALUES INPUTTED BY USER*/
    if (usr == "" && pwd == "") {
        alert("Please Input a Username and Password");
    } else if (usr == "") {
        alert("Please Input a Username");
    } else if (pwd == "") {
        alert("Please Input a Password");
    }

    /*AJAX REQUEST*/
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("Login Successful!") //Will need to be swapped out for a redirect to the homepage

            // Reilly (Added - Redirect)
            //
            window.location.href = "/Homepage.html" ;

        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Login Failed");
        }
    }

    xhttp.open("POST", "/login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({'username':usr,'password':pwd}));
}

// Create Account
function signUp() {
    var usr = document.getElementById("Uname").value;          //Username
    var eml = document.getElementById("emailName").value;      //Email
    var pwd = document.getElementById("Pname").value;          //Password1
    var pwd2 = document.getElementById("confirmPname").value;  //Password2

    if (pwd != pwd2) {//Passwords Do Not Match
        alert("Passwords Do Not Match");
    } else if (eml.includes("@") == false) {
        alert("Please enter a valid email")
    } else if (usr == "") {
        alert("Please Input a Username")
    }

    /*AJAX REQUEST*/
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("Account Created Succesfully") //Will need to be swapped out for a redirect to the log in page

            // Reilly (Added - Redirect)
            //
            window.location.href = "/login.html" ;

        } else if (this.readyState == 4 && this.status >= 400) { //Will need to be updated to add the response for 'user already exists'
            alert("Account Creation Failed");
        }
    }

    xhttp.open("POST", "/signup", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({'username':usr,'password':pwd,'email':eml}));
}


function logout()
{

}

// check for saved 'darkMode' in localStorage
let darkMode = localStorage.getItem('darkMode');
const darkModeToggle = document.getElementById('darkModeButton');
console.log(darkModeToggle)
const lightModeToggle = document.getElementById('lightModeButton');

var allDivs = document.querySelectorAll('div') ;

const enableDarkMode = () => {
  for (var i=0; i <allDivs.length; i++) {
      allDivs[i].classList.add('darkModeThemeDiv');
  }
  localStorage.setItem('darkMode', 'enabled');
}

const disableDarkMode = () => {
  for (var i=0; i<allDivs.length; i++) {
      allDivs[i].classList.remove('darkModeThemeDiv');
  }
  localStorage.setItem('darkMode', null);
}

if (darkMode === 'enabled') {
  enableDarkMode();
}

darkModeToggle.addEventListener('click', () => {
  darkMode = localStorage.getItem('darkMode');
  enableDarkMode();
});


lightModeToggle.addEventListener('click', () => {
    darkMode=localStorage.getItem('darkMode');
    disableDarkMode();
});