//Create variable date which take today as its value;
let date = new Date();

let createCalendar = function() {
    //Set year, month and today variables.
    let currentYear = date.getFullYear();
    let currentMonth = date.getMonth();
    let today = date.toDateString();
    let anniversary = date.toDateString();

    console.log(today);
    //Get days in a month.
    let monthDays = document.querySelector(".days");

    //Get last day in the current month by using getFullYear and getMonth method.
    let lastDay = new Date(
        date.getFullYear(),
        //Because the program will get last month therefore adding 1 then 
        //we will have the month that we are looking at
        date.getMonth() + 1,
        0
    ).getDate();

    //Get first day of the month
    let firstDay = date.getDay();

    //Create an array contains months
    let months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    //Set current month
    document.querySelector("#date h1").innerHTML = months[currentMonth];
    //Set today
    document.querySelector("#date p").innerHTML = today;

    //Create days in a month
    let days = "";

    //Insert blanks in order to get the right calendar
    for (let j = firstDay-2; j > 0; j--) {
        days += `<div></div>`;
    }

    //Console all the dates in a month and highlight today
    for (let i = 1; i <= lastDay; i++) {
        if (i === new Date().getDate() &&
            date.getMonth() === new Date().getMonth()
            && date.getFullYear() === new Date().getFullYear()) {
            days += `<div class = "today">${i}</div>`;
        }
        else days += `<div>${i}</div>`;
    }
    monthDays.innerHTML = days;

};

//Can you check for me this part? Urgent! Line 67 -> 77.
document.getElementById('prev').addEventListener("click", function() {
    date.setMonth(date.getMonth() - 1);
    createCalendar();
});

document.getElementById('next').addEventListener("click", function() {
    date.setMonth(date.getMonth() + 1);
    createCalendar();
});

createCalendar();

document.getElementById('addEvent').addEventListener('click', function(){
    document.querySelector('.bg-modal').style.display = 'flex';
});
document.querySelector('.close').addEventListener('click', function(){
    document.querySelector('.bg-modal').style.display = 'none';
})
