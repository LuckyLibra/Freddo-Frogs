var modal = document.getElementById("add_user_modal") ;
var btn = document.getElementById("add_btn") ;
var close_btn = document.getElementsByClassName("close")[0] ;

// Get add user button in modal
//
var add_user_button = document.getElementsByClassName("add_user_button")[0] ;

// When the user clicks on the button, open the modal
//
btn.onclick = function()
{
    modal.style.display = "block" ;
    document.body.style.overflow = "hidden" ;
}

// When the user clicks on x, close the modal
//
close_btn.onclick = function()
{
    modal.style.display = "none" ;
    document.body.style.overflow = "auto" ;
}

// When the user clicks anywhere outside of the modal, close it
//
window.onclick = function(event) {
    if ( event.target == modal ) {
        modal.style.display = "none" ;
        document.body.style.overflow = "auto" ;
    }
}