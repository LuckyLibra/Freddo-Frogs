var user_session ;

function get_user_session()
{
    var u_uname = document.getElementById( "u_uname" ) ;
    var u_img = document.getElementById( "u_img" ) ;
    var u_email = document.getElementById( "u_email" ) ;
    var u_fname = document.getElementById( "u_fname" ) ;
    var u_lname = document.getElementById( "u_lname" ) ;


    var adm = document.getElementsByClassName('admin') ;

    // AJAX
    var xhttp = new XMLHttpRequest( ) ;

    xhttp.onreadystatechange = function( ) {
        if ( this.readyState == 4 && this.status == 200 ) {
            user_session = JSON.parse(this.responseText) ;

            console.log( user_session ) ;

            if ( user_session.role_ID !== 1 )
            {
                for ( let i = 0 ; i < adm.length ; i++ )
                {
                    adm[i].style.display = 'none' ;
                }

            }

            if ( user_session.username !== null )
            {
                u_uname.innerHTML = user_session.username ;
            }

            if ( user_session.image_url !== null )
            {
                u_img.src = user_session.image_url ;
            }

            if ( user_session.email !== null )
            {
                u_email.innerHTML = user_session.email ;
            }

            if ( user_session.first_name !== null )
            {
                u_fname.innerHTML = user_session.first_name ;
            }

            if ( user_session.last_name !== null )
            {
                u_lname.innerHTML = user_session.last_name ;
            }
         }
    } ;

    xhttp.open( "GET", "/get_session", true ) ;
    xhttp.send( ) ;
}

var preferences = document.getElementById('p_pref') ;
var profile = document.getElementById('p_prof') ;
var admin = document.getElementById('p_admin') ;

function show_preferences()
{
    preferences.style.display = 'block' ;
    profile.style.display = 'none' ;
    admin.style.display = 'none' ;
}

function show_profile()
{
    preferences.style.display = 'none' ;
    profile.style.display = 'block' ;
    admin.style.display = 'none' ;
}

function show_admin()
{
    preferences.style.display = 'none' ;
    profile.style.display = 'none' ;
    admin.style.display = 'block' ;
}


// {/* <h2 onclick="show_profile();" class="settingsTitle clickable">User Profile</h2><hr>
// <h2 onclick="show_admin();" class="settingsTitle clickable">Administration</h2><hr></hr> */}