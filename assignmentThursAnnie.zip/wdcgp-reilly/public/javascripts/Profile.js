
var user_session ;

function get_user_session()
{
    var u_uname = document.getElementById( "u_uname" ) ;
    var u_img = document.getElementById( "u_img" ) ;
    var u_email = document.getElementById( "u_email" ) ;
    var u_fname = document.getElementById( "u_fname" ) ;
    var u_lname = document.getElementById( "u_lname" ) ;

    // AJAX
    var xhttp = new XMLHttpRequest( ) ;

    xhttp.onreadystatechange = function( ) {
        if ( this.readyState == 4 && this.status == 200 ) {
            user_session = JSON.parse(this.responseText) ;

            console.log( user_session ) ;

            if ( user_session.username !== null )
            {
                u_uname.innerHTML = user_session.username ;
            }

            if ( user_session.image_url !== null )
            {
                u_img.src = user_session.image_url ;
            }

            if ( user_session.email !== null )
            {
                u_email.innerHTML = user_session.email ;
            }

            if ( user_session.first_name !== null )
            {
                u_fname.innerHTML = user_session.first_name ;
            }

            if ( user_session.last_name !== null )
            {
                u_lname.innerHTML = user_session.last_name ;
            }
         }
    } ;

    xhttp.open( "GET", "/get_session", true ) ;
    xhttp.send( ) ;
}

function open_modal( section ) {

    if ( section === 'uname' )
    {
        document.getElementById('form_uname').style.display = "block" ;
    }

    if ( section === 'image' )
    {
        document.getElementById('form_image').style.display = "block" ;
    }

    if ( section === 'email' )
    {
        document.getElementById('form_email').style.display = "block" ;
    }

    if ( section === 'fname' )
    {
        document.getElementById('form_fname').style.display = "block" ;
    }

    if ( section === 'lname' )
    {
        document.getElementById('form_lname').style.display = "block" ;
    }

    var details_modal = document.getElementById("details_modal") ;

    details_modal.style.display = "block" ;
    document.body.style.overflow = "hidden" ;

    // When the user clicks on x, close the modal
    //
    var close_btn = document.getElementsByClassName("close")[0] ;

    close_btn.onclick = function() {
        details_modal.style.display = "none" ;
        document.body.style.overflow = "auto" ;
        hide_contents() ;
    }

    // When the user clicks anywhere outside of the modal, close it
    //
    window.onclick = function(event) {
        if (event.target == details_modal) {
            details_modal.style.display = "none" ;
            document.body.style.overflow = "auto" ;
            hide_contents() ;
        }
    }
}

function hide_contents()
{
    document.getElementById('form_uname').style.display = "none" ;
    document.getElementById('form_image').style.display = "none" ;
    document.getElementById('form_email').style.display = "none" ;
    document.getElementById('form_fname').style.display = "none" ;
    document.getElementById('form_lname').style.display = "none" ;
}


/**
 *  AJAX Request to change a users username
 */
function change_username()
{
    var Uname = document.getElementById("uname").value ;          // Username

     // AJAX
     var xhttp = new XMLHttpRequest( ) ;

     xhttp.onreadystatechange = function( ) {
         if ( this.readyState == 4 && this.status == 200 ) {
            get_user_session() ;
         }
     } ;

     xhttp.open( "PUT", "/change_username" ) ;
     xhttp.setRequestHeader( "Content-type", "application/json" ) ;
     xhttp.send( JSON.stringify( { 'username': Uname, 'user_ID': user_session.user_ID } ) ) ;
}

function change_image()
{

}

function change_email()
{
    var Email = document.getElementById("email").value ;          // Email

     // AJAX
     var xhttp = new XMLHttpRequest( ) ;

     xhttp.onreadystatechange = function( ) {
         if ( this.readyState == 4 && this.status == 200 ) {
            get_user_session() ;
         }
     } ;

     xhttp.open( "PUT", "/change_email" ) ;
     xhttp.setRequestHeader( "Content-type", "application/json" ) ;
     xhttp.send( JSON.stringify( { 'email': Email, 'user_ID': user_session.user_ID } ) ) ;
}

function change_firstname()
{
    var Fname = document.getElementById("first").value ;          // First Name

     // AJAX
     var xhttp = new XMLHttpRequest( ) ;

     xhttp.onreadystatechange = function( ) {
         if ( this.readyState == 4 && this.status == 200 ) {
            get_user_session() ;
         }
     } ;

     xhttp.open( "PUT", "/change_firstname" ) ;
     xhttp.setRequestHeader( "Content-type", "application/json" ) ;
     xhttp.send( JSON.stringify( { 'first_name': Fname, 'user_ID': user_session.user_ID } ) ) ;
}

function change_lastname()
{
    var Lname = document.getElementById("last").value ;          // Last Name

     // AJAX
     var xhttp = new XMLHttpRequest( ) ;

     xhttp.onreadystatechange = function( ) {
         if ( this.readyState == 4 && this.status == 200 ) {
            get_user_session() ;
         }
     } ;

     xhttp.open( "PUT", "/change_lastname" ) ;
     xhttp.setRequestHeader( "Content-type", "application/json" ) ;
     xhttp.send( JSON.stringify( { 'last_name': Lname, 'user_ID': user_session.user_ID } ) ) ;
}

