
function is_admin()
{
    let user_session ;

    // AJAX
    var xhttp = new XMLHttpRequest( ) ;

    xhttp.onreadystatechange = function( ) {
        if ( this.readyState == 4 && this.status == 200 ) {
            user_session = JSON.parse(this.responseText) ;

            if ( user_session.role_ID !== 1 )
            {
                alert( "Unauthorised - Only Admins Can View This Content." ) ;
                window.location.replace( '/login.html' ) ;
            }
         }
    } ;

    xhttp.open( "GET", "/get_session", true ) ;
    xhttp.send( ) ;
}

let user_list ;
let ele_select_list = [] ;

/**
 *  If user already exists in table - update user
 *  - For updating roles
 *  ( Couldn't get to work properly with real-time updates,
 *  table will populate again after reload, have done this on Add & Delete User )
 *
 */
function populate_table( )
{

    let grid = document.getElementById("grid") ;

    for ( item in user_list )
    {
        // Update Existing Users Names & Roles.
        //
        try
        {
            let current_name = document.getElementById( "name" + item ) ;
            let current_role = document.getElementById( "role" + item ) ;
            current_name.innerText = user_list[item].username ;
            current_role.innerText = user_list[item].role_name ;
        }

        // Else create new table entry
        //
        catch
        {
            // For display purposes - used to change background colour of rows
            //
            let is_even = true ;
            if ( item % 2 === 0 )
            {
                is_even = false ;
            }

            // Col 0 - Username
            //
            let cell0 = document.createElement("div");
            cell0.innerHTML = user_list[item].username ;
            cell0.id = "name" + item ;
            cell0.className = "td" ;

            grid.appendChild( cell0 ) ;

            // Col 1 - Role name
            //
            let cell1 = document.createElement("div");
            cell1.innerHTML = user_list[item].role_name ;
            cell1.id = "role" + item ;
            cell1.className = "td" ;

            grid.appendChild( cell1 ) ;

            // Col 2 - Select
            //
            let select_list = ["Choose New Role", "Admin", "User"] ;
            var select = document.createElement("select") ;
            select.id = "select" + item ;

            let cell2 = document.createElement("div");
            cell2.id = "select_div" + item ;
            cell2.className = "td" ;

            for (var i = 0; i < select_list.length; i++)
            {
                var option = document.createElement("option") ;
                option.value = i ;
                option.text = select_list[i] ;
                if ( i === 0 )
                {
                    option.selected = true ;
                    option.disabled = true ;
                }
                select.appendChild(option) ;
            }
            ele_select_list.push( select ) ;

            grid.appendChild( cell2 ) ;
            cell2.appendChild(select) ;

            // Row 4 - 'Save' Button
            //
            let btn = document.createElement("button") ;

            btn.innerHTML = "Save" ;
            btn.id = "button" + item ;
            btn.name = user_list[item].username ;

            btn.addEventListener("click", function() {

                let btn_idx = btn.id.replace('button','') ;
                let role_value = ele_select_list[btn_idx] ;
                if ( ele_select_list[btn_idx].value !== 0 )
                {
                    let user_info = { username: btn.name, role_ID: role_value.value } ;
                    change_role( user_info ) ;
                    role_value.selectedIndex = 0 ;
                }

            }) ;

            let cell3 = document.createElement("div");
            cell3.id = "btn_div" + item ;
            cell3.className = "td" ;

            grid.appendChild( cell3 ) ;
            cell3.appendChild(btn) ;

            // Row 5 - Delete User
            //
            let cell4 = document.createElement("div");
            cell4.id = "delete_div" + item ;
            cell4.className = "td" ;

            let icon = document.createElement("i") ;
            icon.innerHTML = '<i class="fa-solid fa-trash-can"></i>' ;
            icon.id = "icon" + item ;
            cell4.appendChild(icon) ;

            icon.addEventListener("click", function() {

                let icon_idx = icon.id.replace('icon','') ;
                let user_info = { username: user_list[icon_idx].username } ;

                document.getElementById( 'delete_p' ).innerText = "Are you sure you want to delete " + user_list[icon_idx].username + "?" ;

                delete_confirmation( user_info ) ;
            }) ;

            grid.appendChild( cell4 ) ;

            // Change background for even rows
            //
            if ( is_even )
            {
                cell0.style.background = 'rgba(109,65,153,0.1)' ;
                cell1.style.background = 'rgba(109,65,153,0.1)' ;
                cell2.style.background = 'rgba(109,65,153,0.1)' ;
                cell3.style.background = 'rgba(109,65,153,0.1)' ;
                cell4.style.background = 'rgba(109,65,153,0.1)' ;
            }
        }
    }
}

/**
 *  AJAX Request to get list of users from Database for use in table
 */
function get_users( )
{
    // AJAX
    var xhttp = new XMLHttpRequest( ) ;

    xhttp.onreadystatechange = function( ) {
        if ( this.readyState == 4 && this.status == 200 ) {
            user_list = JSON.parse(this.responseText) ;
            populate_table() ;
        }
    } ;

    xhttp.open( "GET", "/user_list", true ) ;
    xhttp.send( ) ;
}


/**
 *  AJAX Request to change a users role
 */
function change_role( user )
{
    if ( user.role_ID === '0' )
    {
        alert( "Please choose a valid option..." ) ;
        return ;
    }

    // AJAX
    var xhttp = new XMLHttpRequest( ) ;

    xhttp.onreadystatechange = function( ) {
        if ( this.readyState == 4 && this.status == 200 ) {
            get_users() ;
        }
    } ;

    xhttp.open( "PUT", "/update_role" ) ;
    xhttp.setRequestHeader( "Content-type", "application/json" ) ;
    xhttp.send( JSON.stringify(user) ) ;
}


/**
 *  AJAX Request to Create a New User.
 */
function create_user(  )
{
    var usr = document.getElementById("Uname").value;          //Username
    var eml = document.getElementById("emailName").value;      //Email
    var rl = document.getElementById("Rname").value;           //Role
    var pwd = document.getElementById("Pname").value;          //Password1
    var pwd2 = document.getElementById("confirmPname").value;  //Password2

    if (pwd != pwd2) {//Passwords Do Not Match
        alert("Passwords Do Not Match");
        return ;
    } else if (eml.includes("@") == false) {
        alert("Please enter a valid email");
        return ;
    } else if (usr == "") {
        alert("Please Input a Username");
        return ;
    }

    /*AJAX REQUEST*/
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("Account Created Succesfully") //Will need to be swapped out for a redirect to the log in page
            setTimeout( function() {
                modal.style.display = "none" ;
                document.body.style.overflow = "auto" ;
            }, 1000 ) ;
            location.reload() ;
        } else if (this.readyState == 4 && this.status >= 400) { //Will need to be updated to add the response for 'user already exists'
            alert("Account Creation Failed");
        }
    }

    xhttp.open("POST", "/create_new_user", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({'username':usr,'password':pwd,'role':rl,'email':eml}));
}


/**
 *  AJAX Request to Deletes a User.
 */
function delete_user( user )
{
    /*AJAX REQUEST*/
    var xhttp = new XMLHttpRequest() ;

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            alert("Account Deleted Succesfully") //Will need to be swapped out for a redirect to the log in page
            setTimeout( function() {
                del_modal.style.display = "none" ;
                document.body.style.overflow = "auto" ;
            }, 1000 ) ;
            location.reload() ;
        } else if (this.readyState == 4 && this.status >= 400) { //Will need to be updated to add the response for 'user already exists'
            alert("Delete User Failed") ;
        }
    }

    xhttp.open( "DELETE", "/delete_user" ) ;
    xhttp.setRequestHeader( "Content-type", "application/json" ) ;
    xhttp.send( JSON.stringify(user) ) ;
}


/**
 *  Opens modal - Are you sure you want to delete?
 */
function delete_confirmation( user )
{
    // Get the modal 2
    //
    var del_modal = document.getElementById("delete_user_modal") ;
    var close_btn = document.getElementsByClassName("close")[1] ;
    var delete_user_button = document.getElementsByClassName("delete_user_button")[0] ;

    del_modal.style.display = "block" ;
    document.body.style.overflow = "hidden" ;

    // When the user clicks on delete_user_button, confirm delete
    //
    delete_user_button.onclick = function() {
        console.log(user.username) ;
        delete_user( user ) ;
    }

    // When the user clicks on x, close the modal
    //
    close_btn.onclick = function() {
        del_modal.style.display = "none" ;
        document.body.style.overflow = "auto" ;
    }

    // When the user clicks anywhere outside of the modal, close it
    //
    window.onclick = function(event) {
        if ( event.target == del_modal ) {
            del_modal.style.display = "none" ;
            document.body.style.overflow = "auto" ;
        }
    }
}
